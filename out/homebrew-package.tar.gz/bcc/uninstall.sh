#!/bin/bash

sudo rm /usr/local/bin/bcc
sudo rm /usr/local/bin/bc2c
